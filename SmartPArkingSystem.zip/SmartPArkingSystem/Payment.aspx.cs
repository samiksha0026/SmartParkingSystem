﻿using System;
using System.Data.SqlClient;
using System.Configuration;
namespace SmartPArkingSystem
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Fetch and display the amount
                if (Session["Price"] != null)
                {
                    txtAmount.Text = Session["Price"].ToString();
                }
                else
                {
                    txtAmount.Text = "0"; // Default value
                }

                // Ensure correct visibility on first load
                pnlTransactionID.Visible = ddlPaymentMethod.SelectedValue == "UPI";
            }
        }

        protected void ddlPaymentMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Show/hide transaction ID field based on selected payment method
            pnlTransactionID.Visible = (ddlPaymentMethod.SelectedValue == "UPI");
        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            if (Session["UserID"] != null && Session["Price"] != null)
            {
                int userID = Convert.ToInt32(Session["UserID"]);
                decimal amount = Convert.ToDecimal(Session["Price"]);
                string paymentMethod = ddlPaymentMethod.SelectedValue;
                string transactionID = txtTransactionID.Text.Trim();
                string status = "Success";

                string connStr = ConfigurationManager.ConnectionStrings["SmartParkingDB"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    // Insert payment into database
                    string query = "INSERT INTO Payment (UserID, Price, PaymentMethod, TransactionID, Status) OUTPUT INSERTED.PaymentID VALUES (@UserID, @Price, @PaymentMethod, @TransactionID, @Status)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", userID);
                        cmd.Parameters.AddWithValue("@Price", amount);
                        cmd.Parameters.AddWithValue("@PaymentMethod", paymentMethod);
                        cmd.Parameters.AddWithValue("@TransactionID", string.IsNullOrEmpty(transactionID) ? (object)DBNull.Value : transactionID);
                        cmd.Parameters.AddWithValue("@Status", status);

                        conn.Open();
                        int paymentID = (int)cmd.ExecuteScalar(); // Get inserted PaymentID
                        conn.Close();

                        // Redirect to ticket page with PaymentID
                        Response.Redirect("Ticket.aspx?paymentID=" + paymentID);
                    }
                }
            }
            else
            {
                lblMessage.Text = "Error: User not logged in or amount missing!";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }
    }
}
