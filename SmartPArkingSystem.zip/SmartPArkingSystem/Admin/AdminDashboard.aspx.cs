﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;

namespace SmartPArkingSystem.Admin
{
    public partial class AdminDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Admin"] == null)
            {
                Response.Redirect("AdminLogin.aspx");
            }

            if (!IsPostBack)  // Load data only on first page load
            {
                LoadDashboardData();
            }
        }

        private void LoadDashboardData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["SmartParkingDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Total Users
                string userQuery = "SELECT COUNT(*) FROM Users";
                using (SqlCommand cmd = new SqlCommand(userQuery, conn))
                {
                    lblTotalUsers.Text = cmd.ExecuteScalar().ToString();
                }

                // Total Bookings
                string bookingQuery = "SELECT COUNT(*) FROM Booking";
                using (SqlCommand cmd = new SqlCommand(bookingQuery, conn))
                {
                    lblTotalBookings.Text = cmd.ExecuteScalar().ToString();
                }

                // Total Parking Slots
                string slotsQuery = "SELECT COUNT(*) FROM ParkingSlots";
                using (SqlCommand cmd = new SqlCommand(slotsQuery, conn))
                {
                    lblTotalSlots.Text = cmd.ExecuteScalar().ToString();
                }

                // Total Revenue
                string revenueQuery = "SELECT SUM(TotalAmount) FROM Booking WHERE PaymentStatus='Paid'";
                using (SqlCommand cmd = new SqlCommand(revenueQuery, conn))
                {
                    object result = cmd.ExecuteScalar();
                    lblTotalRevenue.Text = result != DBNull.Value ? result.ToString() : "0";
                }
            }
        }
    }
}
