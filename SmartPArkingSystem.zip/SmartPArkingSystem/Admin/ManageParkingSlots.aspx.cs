﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;

namespace SmartPArkingSystem.Admin
{
    public partial class ManageParkingSlots : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["SmartParkingDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadParkingSlots();
            }
        }

        private void LoadParkingSlots()
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT SlotID, Location, VehicleType, IsAvailable FROM ParkingSlots";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                gvParkingSlots.DataSource = dt;
                gvParkingSlots.DataBind();
            }
        }

        protected void btnAddSlot_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "INSERT INTO ParkingSlots (Location, VehicleType, IsAvailable) VALUES (@Location, @VehicleType, @IsAvailable)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Location", txtLocation.Text);
                    cmd.Parameters.AddWithValue("@VehicleType", ddlVehicleType.SelectedValue);
                    cmd.Parameters.AddWithValue("@IsAvailable", chkAvailable.Checked);
                    cmd.ExecuteNonQuery();
                }
            }

            lblMessage.Text = "Parking slot added successfully!";
            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Visible = true;

            LoadParkingSlots();
        }

        protected void gvParkingSlots_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvParkingSlots.EditIndex = e.NewEditIndex;
            LoadParkingSlots();
        }

        protected void gvParkingSlots_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvParkingSlots.Rows[e.RowIndex];
            int slotID = Convert.ToInt32(gvParkingSlots.DataKeys[e.RowIndex].Value);

            string location = (row.FindControl("txtEditLocation") as TextBox).Text;
            string vehicleType = (row.FindControl("ddlEditVehicleType") as DropDownList).SelectedValue;
            bool isAvailable = (row.FindControl("chkEditAvailable") as CheckBox).Checked;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "UPDATE ParkingSlots SET Location=@Location, VehicleType=@VehicleType, IsAvailable=@IsAvailable WHERE SlotID=@SlotID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Location", location);
                    cmd.Parameters.AddWithValue("@VehicleType", vehicleType);
                    cmd.Parameters.AddWithValue("@IsAvailable", isAvailable);
                    cmd.Parameters.AddWithValue("@SlotID", slotID);
                    cmd.ExecuteNonQuery();
                }
            }

            gvParkingSlots.EditIndex = -1;
            LoadParkingSlots();
        }

        protected void gvParkingSlots_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvParkingSlots.EditIndex = -1;
            LoadParkingSlots();
        }

        // ✅ Added missing RowCommand method
        protected void gvParkingSlots_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "DeleteSlot")
            {
                int slotID = Convert.ToInt32(e.CommandArgument);
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string query = "DELETE FROM ParkingSlots WHERE SlotID=@SlotID";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SlotID", slotID);
                        cmd.ExecuteNonQuery();
                    }
                }

                lblMessage.Text = "Parking slot deleted successfully!";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Visible = true;

                LoadParkingSlots();
            }
        }
    }
}
