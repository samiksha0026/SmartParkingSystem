﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Script.Serialization;

namespace SmartPArkingSystem.Admin
{
    public partial class ReportsAnalytics : System.Web.UI.Page
    {
        protected string SlotUtilizationData = "[]";
        protected string RevenueData = "[]";
        protected string BookingData = "[]";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadChartData();
            }
        }

        private void LoadChartData()
        {
            string connStr = ConfigurationManager.ConnectionStrings["SmartParkingDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // Get Slot Utilization Data
                SqlCommand cmd1 = new SqlCommand("SELECT COUNT(*) AS Total, SUM(CASE WHEN Status = 'Available' THEN 1 ELSE 0 END) AS Available FROM ParkingSlots", conn);
                SqlDataReader reader1 = cmd1.ExecuteReader();
                if (reader1.Read())
                {
                    int totalSlots = Convert.ToInt32(reader1["Total"]);
                    int availableSlots = Convert.ToInt32(reader1["Available"]);
                    int bookedSlots = totalSlots - availableSlots;
                    SlotUtilizationData = new JavaScriptSerializer().Serialize(new int[] { availableSlots, bookedSlots });
                }
                reader1.Close();

                // Get Monthly Revenue Data
                SqlCommand cmd2 = new SqlCommand("SELECT TOP 5 SUM(TotalAmount) AS Revenue FROM Bookings GROUP BY MONTH(BookingDate) ORDER BY MONTH(BookingDate)", conn);
                SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                int[] revenueArray = new int[dt2.Rows.Count];
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    revenueArray[i] = Convert.ToInt32(dt2.Rows[i]["Revenue"]);
                }
                RevenueData = new JavaScriptSerializer().Serialize(revenueArray);

                // Get Daily Booking Trends Data
                SqlCommand cmd3 = new SqlCommand("SELECT COUNT(*) AS Bookings FROM Bookings WHERE BookingDate >= DATEADD(DAY, -5, GETDATE()) GROUP BY CAST(BookingDate AS DATE)", conn);
                SqlDataAdapter da3 = new SqlDataAdapter(cmd3);
                DataTable dt3 = new DataTable();
                da3.Fill(dt3);
                int[] bookingArray = new int[dt3.Rows.Count];
                for (int i = 0; i < dt3.Rows.Count; i++)
                {
                    bookingArray[i] = Convert.ToInt32(dt3.Rows[i]["Bookings"]);
                }
                BookingData = new JavaScriptSerializer().Serialize(bookingArray);
            }
        }
    }
}
