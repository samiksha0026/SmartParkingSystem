﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Web.UI;
using ZXing; // For QR Code Generation
using System.IO;

namespace SmartPArkingSystem
{
    public partial class Ticket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["paymentID"] != null)
                {
                    int paymentID = Convert.ToInt32(Request.QueryString["paymentID"]);
                    LoadTicketDetails(paymentID);
                }
            }
        }

        private void LoadTicketDetails(int paymentID)
        {
            string connStr = ConfigurationManager.ConnectionStrings["SmartParkingDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = @"SELECT b.BookingID, b.VehicleNumber, b.SlotID, b.EntryTime, b.ExitTime, p.Price 
                                 FROM Booking b 
                                 INNER JOIN Payment p ON b.UserID = p.UserID 
                                 WHERE p.PaymentID = @PaymentID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        lblBookingID.Text = reader["BookingID"].ToString();
                        lblVehicleNumber.Text = reader["VehicleNumber"].ToString();
                        lblSlot.Text = reader["SlotID"].ToString(); // Changed ParkingSlot → SlotID
                        lblAmount.Text = reader["Price"].ToString();

                        // Check if EntryTime & ExitTime are NULL before converting
                        lblEntryTime.Text = reader["EntryTime"] != DBNull.Value
                            ? Convert.ToDateTime(reader["EntryTime"]).ToString("yyyy-MM-dd HH:mm:ss")
                            : "Not Entered";

                        lblExitTime.Text = reader["ExitTime"] != DBNull.Value
                            ? Convert.ToDateTime(reader["ExitTime"]).ToString("yyyy-MM-dd HH:mm:ss")
                            : "Not Exited";

                        // Generate QR Code
                        GenerateQRCode(lblVehicleNumber.Text);
                    }
                    conn.Close();
                }
            }
        }

        private void GenerateQRCode(string vehicleNumber)
        {
            try
            {
                var qrWriter = new BarcodeWriter();
                qrWriter.Format = BarcodeFormat.QR_CODE;
                var qrBitmap = qrWriter.Write(vehicleNumber);

                string qrFolderPath = Server.MapPath("~/QR_Codes/");
                if (!Directory.Exists(qrFolderPath))
                {
                    Directory.CreateDirectory(qrFolderPath); // Ensure directory exists
                }

                string qrImagePath = Path.Combine(qrFolderPath, vehicleNumber + ".png");

                // Fix GDI+ error: Ensure file is properly disposed
                using (var stream = new FileStream(qrImagePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    qrBitmap.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                }

                imgQRCode.ImageUrl = "~/QR_Codes/" + vehicleNumber + ".png";
            }
            catch (Exception ex)
            {
                lblError.Text = "QR Code generation failed: " + ex.Message; // Display error message
            }
        }

    }
}
