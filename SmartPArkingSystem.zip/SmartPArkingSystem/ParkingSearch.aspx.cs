﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SmartPArkingSystem
{
    public partial class ParkingSearch : System.Web.UI.Page
    {
        string connStr = ConfigurationManager.ConnectionStrings["SmartParkingDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserID"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtArea.Text))
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    string query = "SELECT ParkingID, Name, City, Area, Price FROM ParkingSpots WHERE Area LIKE @Area";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Area", "%" + txtArea.Text.Trim() + "%");

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    gvParkingSpots.DataSource = dt;
                    gvParkingSpots.DataBind();
                }
            }
        }

        protected void gvParkingSpots_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Book")
            {
                int parkingID = Convert.ToInt32(e.CommandArgument);

                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string slotQuery = "SELECT TOP 1 SlotID FROM ParkingSlots WHERE ParkingID = @ParkingID AND IsAvailable = 1";
                    SqlCommand cmd = new SqlCommand(slotQuery, conn);
                    cmd.Parameters.AddWithValue("@ParkingID", parkingID);

                    object slotResult = cmd.ExecuteScalar();
                    if (slotResult != null)
                    {
                        int slotID = Convert.ToInt32(slotResult);

                        // Retrieve selected parking details
                        foreach (GridViewRow row in gvParkingSpots.Rows)
                        {
                            HiddenField hfParkingID = row.FindControl("hfParkingID") as HiddenField;
                            if (hfParkingID != null && hfParkingID.Value == parkingID.ToString())
                            {
                                string name = row.Cells[1].Text;
                                string city = row.Cells[2].Text;
                                string area = row.Cells[3].Text;
                                string price = row.Cells[4].Text;

                                // Store in session
                                if (decimal.TryParse(price, out decimal validPrice))
                                {
                                    Session["ParkingID"] = parkingID;
                                    Session["SlotID"] = slotID;
                                    Session["ParkingName"] = name;
                                    Session["ParkingCity"] = city;
                                    Session["ParkingArea"] = area;
                                    Session["ParkingPrice"] = validPrice.ToString("F2");

                                    Response.Redirect("BookParking.aspx");
                                }
                                else
                                {
                                    lblMessage.Text = "Error: Invalid parking price. Please try again.";
                                }
                                break;
                            }
                        }
                    }
                    else
                    {
                        lblMessage.Text = "No available slots for this parking.";
                    }
                }
            }
        }
    }
}
